#include <windows.h>

extern "C"
{
  //--------------------------------------------------------------------------------- 
  // ASAP1A_CCP_ComputeKeyFromSeed
  //
  // This function is called from the Flash Tool.
  //---------------------------------------------------------------------------------
   bool __declspec(dllexport) __cdecl ASAP1A_CCP_ComputeKeyFromSeed(char           * seed, 
                                                                     unsigned short   sizeSeed, 
                                                                     char           * key, 
                                                                     unsigned short   maxSizeKey, 
                                                                     unsigned short * sizeKey)
   {
      int i;

      // Example calculation: Key = Negation  of Seed
      for (i = 0; i < maxSizeKey; i++)
      {
         if (i < sizeSeed)
         {
            key[i]= ~seed[i];
         }
         else
         {
            break;
         }
      }
      //-End of Calculation--------------------------

      // Report length of calculated key
      *sizeKey= i;

      // If the return value is false the flash tool stops
      return true;
   }
}
